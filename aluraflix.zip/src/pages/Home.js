import React, { useState, useEffect } from 'react';
import api from '../services/api';
import VideoCard from '../components/VideoCard';
import './Home.css';

const Home = () => {
  const [videos, setVideos] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchVideos = async () => {
      const videoRes = await api.get('/videos');
      const categoryRes = await api.get('/categories');
      setVideos(videoRes.data);
      setCategories(categoryRes.data);
    };
    fetchVideos();
  }, []);

  const deleteVideo = async (id) => {
    await api.delete(`/videos/${id}`);
    setVideos(videos.filter((video) => video.id !== id));
  };

  return (
    <div className="home">
      <div className="highlight">
        {videos[0] && (
          <>
            <h2>{videos[0].title}</h2>
            <iframe src={videos[0].video} title={videos[0].title} />
            <p>{videos[0].description}</p>
          </>
        )}
      </div>
      {categories.map((category) => (
        <div key={category} className="category">
          <h3>{category}</h3>
          <div className="video-list">
            {videos
              .filter((video) => video.category === category)
              .map((video) => (
                <VideoCard key={video.id} video={video} deleteVideo={deleteVideo} />
              ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default Home;
