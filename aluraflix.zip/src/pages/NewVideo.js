import React, { useState } from 'react';
import api from '../services/api';
import './NewVideo.css';

const NewVideo = () => {
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    image: '',
    video: '',
    description: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post('/videos', formData);
    setFormData({
      title: '',
      category: '',
      image: '',
      video: '',
      description: '',
    });
  };

  return (
    <div className="new-video">
      <h2>Novo Vídeo</h2>
      <form onSubmit={handleSubmit}>
        <input name="title" placeholder="Título" value={formData.title} onChange={handleChange} required />
        <select name="category" value={formData.category} onChange={handleChange} required>
          <option value="">Selecione uma Categoria</option>
          <option value="Frontend">Frontend</option>
          <option value="Backend">Backend</option>
          <option value="Mobile">Mobile</option>
        </select>
        <input name="image" placeholder="Link da Imagem" value={formData.image} onChange={handleChange} required />
        <input name="video" placeholder="Link do Vídeo" value={formData.video} onChange={handleChange} required />
        <textarea name="description" placeholder="Descrição" value={formData.description} onChange={handleChange} />
        <button type="submit">Salvar</button>
      </form>
    </div>
  );
};

export default NewVideo;
