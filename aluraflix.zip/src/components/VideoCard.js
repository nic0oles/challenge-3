import React from 'react';
import './VideoCard.css';

const VideoCard = ({ video, deleteVideo }) => (
  <div className="video-card">
    <img src={video.image} alt={video.title} />
    <h4>{video.title}</h4>
    <p>{video.category}</p>
    <button onClick={() => window.open(video.video, '_blank')}>Assistir</button>
    <button onClick={() => deleteVideo(video.id)}>Deletar</button>
    {/* Adicionar lógica para editar */}
  </div>
);

export default VideoCard;
