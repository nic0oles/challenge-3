import React from 'react';
import './Modal.css';

const Modal = ({ isOpen, onClose, video, onSave }) => {
  if (!isOpen) return null;

  const [form, setForm] = React.useState({
    titulo: video?.titulo || '',
    categoria: video?.categoria || 'frontend',
    imagem: video?.imagem || '',
    video: video?.video || '',
    descricao: video?.descricao || '',
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(form);
    onClose();
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <div className="modal-header">
          <h2>{video ? 'Editar Card' : 'Novo Card'}</h2>
          <button onClick={onClose}>&times;</button>
        </div>
        <div className="modal-body">
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="titulo"
              placeholder="Título"
              value={form.titulo}
              onChange={handleChange}
              required
            />
            <select
              name="categoria"
              value={form.categoria}
              onChange={handleChange}
              required
            >
              <option value="frontend">Frontend</option>
              <option value="backend">Backend</option>
              <option value="mobile">Mobile</option>
            </select>
            <input
              type="url"
              name="imagem"
              placeholder="Link da imagem"
              value={form.imagem}
              onChange={handleChange}
              required
            />
            <input
              type="url"
              name="video"
              placeholder="Link do vídeo"
              value={form.video}
              onChange={handleChange}
              required
            />
            <textarea
              name="descricao"
              placeholder="Descrição"
              rows="3"
              value={form.descricao}
              onChange={handleChange}
            />
            <button type="submit">Salvar</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Modal;
